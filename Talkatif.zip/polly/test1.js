// Initialize AWS SDK
AWS.config.update({
    region: 'us-east-1', // Replace with your AWS region
    credentials: new AWS.Credentials('AKIAVM22HSHLJKMLYEFA', 'zU50DeXgbd32eIPSkGrRqyvBNbKUhEc8QvtM6Gzh'), // Replace with your AWS access key and secret key
  });
  
  // Initialize Polly and Transcribe clients
  var polly = new AWS.Polly();
  var transcribe = new AWS.TranscribeService();
  
  // Function to convert text to speech
  function convertTextToSpeech() {
    var textToConvert = document.getElementById('textToConvert').value;
  
    var params = {
      OutputFormat: 'mp3',
      Text: textToConvert,
      VoiceId: 'Joanna', // You can choose a different voice
    };
  
    polly.synthesizeSpeech(params, function(err, data) {
      if (err) console.log(err, err.stack);
      else {
        var audioPlayer = document.getElementById('audioPlayer');
        audioPlayer.src = "data:audio/mp3;base64," + data.AudioStream.toString('base64');
        audioPlayer.play();
      }
    });
  }
  
  // Function to convert speech to text
  function convertSpeechToText() {
    var audioInput = document.getElementById('audioInput');
    var file = audioInput.files[0];
  
    var params = {
      LanguageCode: 'en-US', // Replace with the appropriate language code
      Media: {MediaFileUri: URL.createObjectURL(file)},
    };
  
    transcribe.startTranscriptionJob(params, function(err, data) {
      if (err) console.log(err, err.stack);
      else {
        checkTranscriptionStatus(data.TranscriptionJob.TranscriptionJobName);
      }
    });
  }
  
  // Function to check transcription status
  function checkTranscriptionStatus(jobName) {
    var params = {TranscriptionJobName: jobName};
  
    transcribe.getTranscriptionJob(params, function(err, data) {
      if (err) console.log(err, err.stack);
      else {
        if (data.TranscriptionJob.TranscriptionJobStatus === 'COMPLETED') {
          displayTranscriptionResult(data.TranscriptionJob.Transcript.TranscriptFileUri);
        } else if (data.TranscriptionJob.TranscriptionJobStatus === 'FAILED') {
          console.log('Transcription failed');
        } else {
          setTimeout(function() {
            checkTranscriptionStatus(jobName);
          }, 5000); // Check status every 5 seconds
        }
      }
    });
  }
  
  // Function to display transcription result
  function displayTranscriptionResult(transcriptFileUri) {
    $.get(transcriptFileUri, function(data) {
      var transcriptionResult = JSON.parse(data);
      document.getElementById('transcriptionResult').innerText = transcriptionResult.results.transcripts[0].transcript;
    });
  }
  