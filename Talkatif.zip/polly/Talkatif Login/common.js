AWS.config.accessKeyId = 'AKIAVM22HSHLJKMLYEFA'
AWS.config.secretAccessKey = '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'
AWS.config.regoin = 'us-west-1';

var polly = new AWS.Polly();
var params = {
    OutputFormat: "mp3",
    Text: "Hello Hymns.py, how are you today? ",
    TextType: "text",
    VoiceId: "Joanna"
};

polly.synthesizeSpeech(params, function(err, data) {

    if(err){
        //an error occured
        console.log(err, err.stack);
    }
    else{

        var uInt8Array = new Uint8Array(data.AudioStream);
        var arrayBuffer = uInt8Array.buffer;
        var blob = new Blob([arrayBuffer]);

        var audio = $('audio');
        var url = URL.createObjectURL(blob);
        audio[0].src=url;
        audio[0].play();
    }
    });
