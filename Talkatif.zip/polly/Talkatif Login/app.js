// Initialize AWS SDK
AWS.config.update({
    region: 'us-east-1', // Replace with your AWS region
    credentials: new AWS.Credentials('AKIAVM22HSHLJKMLYEFA', 'zU50DeXgbd32eIPSkGrRqyvBNbKUhEc8QvtM6Gzh'), // Replace with your AWS access key and secret key
  }); // Replace with your AWS Region
const transcribe = new AWS.TranscribeService();

// Get the necessary DOM elements
const startButton = document.getElementById('startRecording');
const transcriptionDiv = document.getElementById('transcription');

// Event listener for the "Start Recording" button
startButton.addEventListener('click', async () => {
    try {
        const mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const audioContext = new AudioContext();
        const audioSource = audioContext.createMediaStreamSource(mediaStream);

        // Start recording audio
        const audioChunks = [];
        const recorder = new MediaRecorder(audioSource);
        recorder.ondataavailable = (e) => audioChunks.push(e.data);
        recorder.onstop = async () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });

            // Transcribe the recorded audio
            const params = {
                LanguageCode: 'en-US', // Specify the language code
                Media: { MediaFileUri: URL.createObjectURL(audioBlob) },
            };

            const transcriptionResult = await transcribe.startTranscriptionJob(params).promise();
            const transcriptionText = transcriptionResult.TranscriptionJob.Transcript.TranscriptFileUri;

            transcriptionDiv.textContent = `Transcription: ${transcriptionText}`;
        };

        recorder.start();
        setTimeout(() => recorder.stop(), 50000); // Record for 5 seconds
    } catch (error) {
        console.error('Error:', error);
    }
});